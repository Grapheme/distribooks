-- phpMyAdmin SQL Dump
-- version 3.4.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 18 2013 г., 11:53
-- Версия сервера: 5.1.71
-- Версия PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `distribbooks`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vkid` int(10) unsigned DEFAULT NULL,
  `vk_access_token` text NOT NULL,
  `facebook_access_token` text NOT NULL,
  `facebookid` bigint(20) unsigned DEFAULT NULL,
  `group` tinyint(1) NOT NULL DEFAULT '1',
  `login` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `signdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `language` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `basket` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `group` (`group`),
  KEY `language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `vkid`, `vk_access_token`, `facebook_access_token`, `facebookid`, `group`, `login`, `email`, `password`, `signdate`, `active`, `language`, `basket`) VALUES
(1, NULL, '', '', NULL, 1, 'admin', 'admin@distribbooks.ru', 'e10adc3949ba59abbe56e057f20f883e', '2013-07-30 07:54:52', 1, 1, ''),
(2, NULL, '', '', NULL, 2, 'id2', 'sm@grapheme.ru', '96be28150d49ce2bf16007eb3538c2da', '2013-11-08 12:43:07', 1, 1, ''),
(3, NULL, '', '', NULL, 2, 'id3', 'ks-t77@yandex.ru', '96a3a46d4af58c9104008ee199e788cd', '2013-11-12 08:36:01', 1, 1, '');

-- --------------------------------------------------------

--
-- Структура таблицы `age_limit`
--

DROP TABLE IF EXISTS `age_limit`;
CREATE TABLE IF NOT EXISTS `age_limit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `age_limit`
--

INSERT INTO `age_limit` (`id`, `title`, `image`) VALUES
(1, '0+', 'download/age_limits/0.png'),
(2, '6+', 'download/age_limits/6.png'),
(3, '12+', 'download/age_limits/12.png'),
(4, '16+', 'download/age_limits/16.png'),
(5, '18+', 'download/age_limits/18.png');

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ru_name` varchar(100) NOT NULL,
  `en_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`id`, `ru_name`, `en_name`) VALUES
(1, 'Chris Fidao', 'Chris Fidao'),
(2, 'Мара Брюер', 'Mara Brewer'),
(4, 'Роман Сидельник', 'Roman Sidelnik');

-- --------------------------------------------------------

--
-- Структура таблицы `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(200) NOT NULL,
  `en_title` varchar(200) NOT NULL,
  `ru_anonce` text NOT NULL,
  `en_anonce` text NOT NULL,
  `ru_text` text NOT NULL,
  `en_text` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  `date_released` varchar(50) NOT NULL,
  `ru_size` varchar(50) NOT NULL,
  `en_size` varchar(50) NOT NULL,
  `isbn` varchar(50) NOT NULL,
  `ru_sort` int(10) unsigned NOT NULL,
  `en_sort` int(10) unsigned NOT NULL DEFAULT '0',
  `age_limit` int(10) unsigned NOT NULL,
  `authors` text NOT NULL,
  `files` text NOT NULL,
  `genre` int(10) unsigned NOT NULL,
  `rating` tinyint(2) unsigned NOT NULL,
  `currency` int(10) unsigned NOT NULL DEFAULT '1',
  `price` float unsigned NOT NULL,
  `price_action` float unsigned NOT NULL,
  `trailers` text NOT NULL,
  `audio_recording` text NOT NULL,
  `ru_copyright` text NOT NULL,
  `en_copyright` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `books`
--

INSERT INTO `books` (`id`, `ru_title`, `en_title`, `ru_anonce`, `en_anonce`, `ru_text`, `en_text`, `image`, `thumbnail`, `date_released`, `ru_size`, `en_size`, `isbn`, `ru_sort`, `en_sort`, `age_limit`, `authors`, `files`, `genre`, `rating`, `currency`, `price`, `price_action`, `trailers`, `audio_recording`, `ru_copyright`, `en_copyright`) VALUES
(8, 'Слепое знамя дураков', 'Слепое знамя дураков', 'Вечная борьба добра и зла... Свет и тьма... Возможно ли, чтобы приверженец одной из сторон по собственному желанию перешёл на 1 другую? Может ли нечисть ступить на путь воинов добра и света? Может ли предводитель светлых сил поддаться влиянию своей тёмной стороны? ', 'Вечная борьба добра и зла... Свет и тьма... Возможно ли, чтобы приверженец одной из сторон по собственному желанию перешёл на 1 другую? Может ли нечисть ступить на путь воинов добра и света? Может ли предводитель светлых сил поддаться влиянию своей тёмной стороны? ', '<p>\n	 Вечная борьба добра и зла... Свет и тьма... Возможно ли, чтобы приверженец одной из сторон по собственному желанию перешёл на 1 другую? Может ли нечисть ступить на путь воинов добра и света? Может ли предводитель светлых сил поддаться влиянию своей тёмной стороны?\n</p>\n<p>\n	 События этой истории начинаются в 1930 году, но предпосылки её развития уходят своими корнями еще в начало XIX века. Служители светлых и темных сил ожидают рождения дочери Дьявола. Разумеется, есть и тот единственный, кто способен спасти мир от вечной тьмы. Но главным препятствием на его пути является любовь к могущественной ведьме, пытающейся склонить его на сторону зла. <br>\n	 Телепатия, левитация, бессмертие, перемещение во времени и пространстве — вот с чем непрерывно сталкиваются герои этой истории. Но смысл жизни для каждого из них — это вечная любовь, которую и называют слепым знаменем дураков. Кому удастся <br>\n	 противостоять искушению, а кому нет? Кто сможет сохранить самое <br>\n	 ценное в своих сердцах и одержать победу в этой борьбе? Об этом вы узнаете на страницах книги издательства Distri6Books «Слепое знамя дураков»!\n</p>', '<p>\n	 Вечная борьба добра и зла... Свет и тьма... Возможно ли, чтобы  приверженец одной из сторон по собственному желанию перешёл на 1 другую?  Может ли нечисть ступить на путь воинов добра и света? Может ли  предводитель светлых сил поддаться влиянию своей тёмной стороны?\n</p>\n<p>\n	 События  этой истории начинаются в 1930 году, но предпосылки её развития уходят  своими корнями еще в начало XIX века. Служители светлых и темных сил  ожидают рождения дочери Дьявола. Разумеется, есть и тот единственный,  кто способен спасти мир от вечной тьмы. Но главным препятствием на его  пути является любовь к могущественной ведьме, пытающейся склонить его на  сторону зла. <br>\n	 Телепатия, левитация, бессмертие, перемещение во  времени и пространстве — вот с чем непрерывно сталкиваются герои этой  истории. Но смысл жизни для каждого из них — это вечная любовь, которую и  называют слепым знаменем дураков. Кому удастся <br>\n	 противостоять искушению, а кому нет? Кто сможет сохранить самое <br>\n	 ценное  в своих сердцах и одержать победу в этой борьбе? Об этом вы узнаете на  страницах книги издательства Distri6Books «Слепое знамя дураков»!\n</p>', 'download/books/549275493692.png', 'download/books/597254919621.png', '2013', '285', '285', '', 3, 0, 5, '2,4', '[{"file_name":"227355577793.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/227355577793.pdf","raw_name":"227355577793","orig_name":"227355577793.pdf","client_name":"Slepoe_znamya_durakov_rus.pdf","file_ext":".pdf","file_size":1957.48,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"7","number":1,"sort":1,"caption":""}]', 6, 0, 1, 321, 0, '[""]', '[""]', 'Distribbooks', 'Distribbooks'),
(9, 'The blind banner of the fools', 'The blind banner of the fools', '​The everlasting fight between good and bad... Dark and light... Can a follower of one side voluntarily change the sides? Can the evil spirits 1 take the road of the warriors of good and light? Can the leader of the light powers yield to the influence of his dark side?', '​The everlasting fight between good and bad... Dark and light... Can a follower of one side voluntarily change the sides? Can the evil spirits 1 take the road of the warriors of good and light? Can the leader of the light powers yield to the influence of his dark side?', '<p>\n	 The everlasting fight between good and bad... Dark and light... Can a follower of one side voluntarily change the sides? Can the evil spirits 1 take the road of the warriors of good and light? Can the leader of the light powers yield to the influence of his dark side? The events of this story start in 1930 but the prerequisites of its development root themselves in the beginning of the 19''h century. The servants of the light and dark powers are expecting the birth of the Devil''s daughter. There is, certainly, the only one who is able to save the world from the enternal dark. But the main obstacle is his love towards the mighty witch trying to incline him to the evil side. The telepathy, levitation, immortality, shifting in time and space — the characters of this story are constantly facing all this. But the life sense for each of them is the eternal love that is called a blind banner of the fools. Who will succeed in resisting the temptation, and who will fail? Who will manage to preserve what is the most precious in their hearts and gain a victory in this struggle? You will learn about it from the pages of the book the Blind Banner Of the Foolso published by DistrihBooks!\n</p>', '<p>\n	 The everlasting fight between good and bad... Dark and light... Can a  follower of one side voluntarily change the sides? Can the evil spirits  1 take the road of the warriors of good and light? Can the leader of  the light powers yield to the influence of his dark side? The events of  this story start in 1930 but the prerequisites of its development root  themselves in the beginning of the 19''h century. The servants of the  light and dark powers are expecting the birth of the Devil''s daughter.  There is, certainly, the only one who is able to save the world from the  enternal dark. But the main obstacle is his love towards the mighty  witch trying to incline him to the evil side. The telepathy, levitation,  immortality, shifting in time and space — the characters of this story  are constantly facing all this. But the life sense for each of them is  the eternal love that is called a blind banner of the fools. Who will  succeed in resisting the temptation, and who will fail? Who will manage  to preserve what is the most precious in their hearts and gain a victory  in this struggle? You will learn about it from the pages of the book  the Blind Banner Of the Foolso published by DistrihBooks!\n</p>', 'download/books/496139153251.png', 'download/books/426639496448.png', '2013', '325', '325', '978-5-906492-05-0', 5, 0, 5, '2,4', '[{"file_name":"875812751442.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/875812751442.pdf","raw_name":"875812751442","orig_name":"875812751442.pdf","client_name":"The_blind_banner_of the_fools.pdf","file_ext":".pdf","file_size":1697.11,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"7","number":1,"sort":1,"caption":""}]', 6, 0, 1, 321, 0, '["<iframe width=\\"330\\" height=\\"200\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '[""]', 'Distribbooks', 'Distribbooks'),
(2, 'Фанатка', 'Фанатка', 'Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.', 'Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.', '<p>\n	                      Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.\n</p>\n<p>\n	                      Элис случайно узнаёт, что одна из её подруг обладает способностью читать мысли и заглядывать в будущее. Всё осложняется, когда однажды, используя свои способности, девушка оказалась неразрывно связанной на астральном уровне с одним из солистов группы, который теперь живёт сразу в двух мирах: в одном — он рок-звезда, страдающая от алкоголизма, в другом — обычный парень, влюблённый в прекрасную девушку Анжелу, подругу Элис.  К чему приведут игры с чужим подсознанием, вы узнаете, прочитав книгу издательства DistribBooks «Фанатка»!\n</p>', '<p>\n	    Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.\n</p>\n<p>\n	    Элис случайно узнаёт, что одна из её подруг обладает способностью читать мысли и заглядывать в будущее. Всё осложняется, когда однажды, используя свои способности, девушка оказалась неразрывно связанной на астральном уровне с одним из солистов группы, который теперь живёт сразу в двух мирах: в одном — он рок-звезда, страдающая от алкоголизма, в другом — обычный парень, влюблённый в прекрасную девушку Анжелу, подругу Элис.  К чему приведут игры с чужим подсознанием, вы узнаете, прочитав книгу издательства DistribBooks «Фанатка»!\n</p>', 'download/books/269531152943.png', 'download/books/558699912363.png', '2013-09-01', '115 стр.', '386', '-', 1, 0, 5, '2', '[{"file_name":"588459342635.epub","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/588459342635.epub","raw_name":"588459342635","orig_name":"588459342635.epub","client_name":"Fanatka - Pivovarova Marina.epub","file_ext":".epub","file_size":392.17,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"2","number":1,"sort":1,"caption":""},{"file_name":"711258154738.fb2","file_type":"application\\/xml","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/711258154738.fb2","raw_name":"711258154738","orig_name":"711258154738.fb2","client_name":"Fanatka - Pivovarova Marina.fb2","file_ext":".fb2","file_size":1174.1,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"1","number":2,"sort":2,"caption":""},{"file_name":"955763429587.lit","file_type":"application\\/x-ms-reader","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/955763429587.lit","raw_name":"955763429587","orig_name":"955763429587.lit","client_name":"Fanatka - Pivovarova Marina.lit","file_ext":".lit","file_size":439.23,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"16","number":3,"sort":3,"caption":""},{"file_name":"521913859278.lrf","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/521913859278.lrf","raw_name":"521913859278","orig_name":"521913859278.lrf","client_name":"Fanatka - Pivovarova Marina.lrf","file_ext":".lrf","file_size":476.55,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"15","number":4,"sort":4,"caption":""},{"file_name":"439929365242.rb","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/439929365242.rb","raw_name":"439929365242","orig_name":"439929365242.rb","client_name":"Fanatka - Pivovarova Marina.rb","file_ext":".rb","file_size":751.61,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"14","number":5,"sort":5,"caption":""},{"file_name":"217786773597.mobi","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/217786773597.mobi","raw_name":"217786773597","orig_name":"217786773597.mobi","client_name":"Fanatka2 - Pivovarova Marina.mobi","file_ext":".mobi","file_size":793.07,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"10","number":6,"sort":6,"caption":""},{"file_name":"814357111721.rtf","file_type":"text\\/rtf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/814357111721.rtf","raw_name":"814357111721","orig_name":"814357111721.rtf","client_name":"Fanatka2 - Pivovarova Marina.rtf","file_ext":".rtf","file_size":3521.39,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"6","number":7,"sort":7,"caption":""},{"file_name":"366294343868.txt","file_type":"text\\/plain","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/366294343868.txt","raw_name":"366294343868","orig_name":"366294343868.txt","client_name":"Fanatka2 - Pivovarova Marina.txt","file_ext":".txt","file_size":1007.53,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"5","number":8,"sort":8,"caption":""}]', 3, 0, 1, 321, 0, '["<iframe width=\\"330\\" height=\\"200\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '[""]', 'Distribbooks', 'Distribbooks'),
(6, 'The Fangirl', 'The Fangirl', 'THE FANGIRL This is a lifestory of Alice, a romantic girl who believes in all the supernatural. She and her three friends are the fans of a famous rock-group, the leading singers of which, the twin brothers Stewarts, are the sex symbols of the modern music. ', 'THE FANGIRL This is a lifestory of Alice, a romantic girl who believes in all the supernatural. She and her three friends are the fans of a famous rock-group, the leading singers of which, the twin brothers Stewarts, are the sex symbols of the modern music. ', '<p>\n	 This is a lifestory of Alice, a romantic girl who believes in all the supernatural. She and her three friends are the fans of a famous rock-group, the leading singers of which, the twin brothers Stewarts, are the sex symbols of the modern music. Accidentally Alice finds out the ability of one of her friends to read thoughts and to look into the future. Everything gets complicated when, while applying her ability, the girl appears to be connected at the astral level with one of the leading singers of the group who lives now in two worlds: in one — he is an alcohol addicted rock-star, in the other — he is an ordinary guy in love with a beautiful girl, Angela, Alice''s friend. You will find out what playing with somebody elses''s sub-consciousness will lead to, while reading the book.\n</p>', '<p>\n	       This is a lifestory of Alice, a romantic girl who believes in all the  supernatural. She and her three friends are the fans of a famous  rock-group, the leading singers of which, the twin brothers Stewarts,  are the sex symbols of the modern music. Accidentally Alice finds out  the ability of one of her friends to read thoughts and to look into the  future. Everything gets complicated when, while applying her ability,  the girl appears to be connected at the astral level with one of the  leading singers of the group who lives now in two worlds: in one — he is  an alcohol addicted rock-star, in the other — he is an ordinary guy in  love with a beautiful girl, Angela, Alice''s friend. You will find out  what playing with somebody elses''s sub-consciousness will lead to, while  reading the book.\n</p>', 'download/books/858743932783.png', 'download/books/673898241256.png', '2013', '386', '386', '', 4, 0, 5, '2,4', '[{"file_name":"887168743239.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/887168743239.pdf","raw_name":"887168743239","orig_name":"887168743239.pdf","client_name":"The_Fangirl.pdf","file_ext":".pdf","file_size":2235.02,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"7","number":1,"sort":1,"caption":""}]', 1, 0, 1, 321, 0, '[""]', '[""]', 'Distribbooks', 'Distribbooks'),
(7, 'Софтмен', 'Softman', '​Известно, что сегодня наш мозг использует лишь малую часть своего потенциала. А теперь представьте, что эту ситуацию удалось изменить... И всего через несколько десятилетий человечество - научилось использовать биологические и нанотехнологические разработки для усовершенствования возможностей головного мозга.', '​Известно, что сегодня наш мозг использует лишь малую часть своего потенциала. А теперь представьте, что эту ситуацию удалось изменить... И всего через несколько десятилетий человечество - научилось использовать биологические и нанотехнологические разработки для усовершенствования возможностей головного мозга.', '<p>\n	      Известно, что сегодня наш мозг использует лишь малую часть своего потенциала. А теперь представьте, что эту ситуацию удалось изменить... И всего через несколько десятилетий человечество - научилось использовать биологические и нанотехнологические разработки для усовершенствования возможностей головного мозга. Но все оказалось не так простои безопасно... Ведь всегда найдутся люди, наделенные властью и жаждущие злоупотреблять ею в своих корыстных интересах. Альто Марини — старший надзиратель кибертюрьмы, построенной для содержания и пыток нарушителей политического режима Объединённого Правительства планеты Земля. Вот уже восемь лет в Альто безрезультатно ищет своего без вести пропавшего старшего брата. И когда Альто, казалось бы, приближается к разгадке тайны его исчезновения, жизнь и социальный статус Марини-младшего изменяются кардинально... Вот уже и он сам оказывается вне режима и вне закона, а его биочип "интеллектум" обнулён. Теперь сама судьба даёт ему шанс пересмотреть свои жизненные ценности и приоритеты. Какие преграды, приключения и откровения ждут героев этой истории на пути противостояния порочной системе? Обо всем этом вы узнаете, прочитав книгу издательства DistribBooks.\n</p>', '<p>\n	      Известно, что сегодня наш мозг использует лишь малую часть своего  потенциала. А теперь представьте, что эту ситуацию удалось изменить... И  всего через несколько десятилетий человечество - научилось использовать  биологические и нанотехнологические разработки для усовершенствования  возможностей головного мозга. Но все оказалось не так простои  безопасно... Ведь всегда найдутся люди, наделенные властью и жаждущие  злоупотреблять ею в своих корыстных интересах. Альто Марини — старший  надзиратель кибертюрьмы, построенной для содержания и пыток нарушителей  политического режима Объединённого Правительства планеты Земля. Вот уже  восемь лет в Альто безрезультатно ищет своего без вести пропавшего  старшего брата. И когда Альто, казалось бы, приближается к разгадке  тайны его исчезновения, жизнь и социальный статус Марини-младшего  изменяются кардинально... Вот уже и он сам оказывается вне режима и вне  закона, а его биочип "интеллектум" обнулён. Теперь сама судьба даёт ему  шанс пересмотреть свои жизненные ценности и приоритеты. Какие преграды,  приключения и откровения ждут героев этой истории на пути противостояния  порочной системе? Обо всем этом вы узнаете, прочитав книгу издательства  DistribBooks.\n</p>', 'download/books/252154935343.png', 'download/books/283945959393.png', '2013', '266', '', '', 2, 0, 5, '2,4', '[{"file_name":"389473843642.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/389473843642.pdf","raw_name":"389473843642","orig_name":"389473843642.pdf","client_name":"Softmen.pdf","file_ext":".pdf","file_size":2071,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"7","number":1,"sort":1,"caption":""}]', 6, 0, 1, 321, 0, '["<iframe width=\\"330\\" height=\\"200\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '[""]', 'Distribbooks', ''),
(10, 'Temptation Island', 'Temptation Island', 'Andy Fernandes, a policeman from Denver, sick and tired of the routine work at the police station, participates in the casting for a new TV show and as a member of the selected group heads for the island to be tested.', 'Andy Fernandes, a policeman from Denver, sick and tired of the routine work at the police station, participates in the casting for a new TV show and as a member of the selected group heads for the island to be tested.', '<p>\n	 Andy Fernandes, a policeman from Denver, sick and tired of the routine work at the police station, participates in the casting for a new TV show and as a member of the selected group heads for the island to be tested.\n</p>\n<p>\n	 Before leaving he receives the task from his chief — to watch over one of the show participants who is the daughter of a recently murdered FBI agent. While preparing for shooting Andy studies his competitors and comes to the conclusion that the people chosen are not the best candidates but, rather, a handful of losers. Later on he finds out that they have been selected to search for the treasures hidden according to the medieval legend of pirates. The island meets the show participants with the dangerous adventures, love and intrigues, mystic events and the awareness of the need of self-improvement. Why exactly these people have been chosen, what trials the characters of this story will have to live through and what every participant of the show will find for himself, read in the book sThe Island Of Temptations: The Unreal Shown published by DistribBooks!\n</p>', '<p>\n	 Andy Fernandes, a policeman from Denver, sick and tired of the  routine work at the police station, participates in the casting for a  new TV show and as a member of the selected group heads for the island  to be tested.\n</p>\n<p>\n	 Before leaving he receives the task from his chief —  to watch over one of the show participants who is the daughter of a  recently murdered FBI agent. While preparing for shooting Andy studies  his competitors and comes to the conclusion that the people chosen are  not the best candidates but, rather, a handful of losers. Later on he  finds out that they have been selected to search for the treasures  hidden according to the medieval legend of pirates. The island meets the  show participants with the dangerous adventures, love and intrigues,  mystic events and the awareness of the need of self-improvement. Why  exactly these people have been chosen, what trials the characters of  this story will have to live through and what every participant of the  show will find for himself, read in the book sThe Island Of Temptations:  The Unreal Shown published by DistribBooks!\n</p>', 'download/books/749158666129.png', 'download/books/488754395657.png', '2013', '223', '223', '978-5-906492-03-6', 6, 0, 5, '2,4', '[{"file_name":"535915989993.pdf","file_type":"application\\/pdf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/535915989993.pdf","raw_name":"535915989993","orig_name":"535915989993.pdf","client_name":"Temptation_Island_eng.pdf","file_ext":".pdf","file_size":1534.67,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"7","number":1,"sort":1,"caption":""}]', 1, 0, 1, 321, 0, '["<iframe width=\\"330\\" height=\\"200\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '[""]', 'Distribbooks', 'Distribbooks');

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `books_card`
--
DROP VIEW IF EXISTS `books_card`;
CREATE TABLE IF NOT EXISTS `books_card` (
`meta_id` int(10) unsigned
,`page_address` varchar(200)
,`ru_page_title` text
,`ru_page_description` text
,`ru_page_h1` text
,`en_page_title` text
,`en_page_description` text
,`en_page_h1` text
,`id` int(10) unsigned
,`ru_title` varchar(200)
,`en_title` varchar(200)
,`ru_anonce` text
,`en_anonce` text
,`ru_text` text
,`en_text` text
,`image` varchar(100)
,`thumbnail` varchar(100)
,`date_released` varchar(50)
,`ru_size` varchar(50)
,`en_size` varchar(50)
,`isbn` varchar(50)
,`ru_sort` int(10) unsigned
,`en_sort` int(10) unsigned
,`age_limit` int(10) unsigned
,`authors` text
,`files` text
,`genre` int(10) unsigned
,`rating` tinyint(2) unsigned
,`currency` int(10) unsigned
,`price` float unsigned
,`price_action` float unsigned
,`trailers` text
,`audio_recording` text
,`ru_copyright` text
,`en_copyright` text
);
-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dollar_rate` double NOT NULL,
  `free_book` tinyint(1) unsigned NOT NULL,
  `count_free_book` tinyint(1) unsigned NOT NULL,
  `action_price` float unsigned NOT NULL,
  `action_percent` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `config`
--

INSERT INTO `config` (`id`, `dollar_rate`, `free_book`, `count_free_book`, `action_price`, `action_percent`) VALUES
(1, 32.6241134751773, 4, 1, 2000, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `currency`
--

DROP TABLE IF EXISTS `currency`;
CREATE TABLE IF NOT EXISTS `currency` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `currency`
--

INSERT INTO `currency` (`id`, `title`, `image`) VALUES
(1, 'RUR', ''),
(2, 'USD', '');

-- --------------------------------------------------------

--
-- Структура таблицы `formats`
--

DROP TABLE IF EXISTS `formats`;
CREATE TABLE IF NOT EXISTS `formats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sort` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `formats`
--

INSERT INTO `formats` (`id`, `category`, `title`, `description`, `image`, `visible`, `sort`) VALUES
(1, 1, '.fb2', 'открытый формат на основе XML, напрямую читается программой HaaIi Readerи многими другими. Читалки и редакторы существуют для практически любой ОС. Существует так же программа конвертер FB2Any;', 'download/formats/687275461694.png', 1, 1),
(2, 1, '.epub', 'активно продвигаемый фирмой Adobe формат, основанный на HTML. Поддерживается практически во всех современных программах и устройствах;', 'download/formats/586651371165.png', 1, 3),
(5, 2, '.txt', 'стандартный текстовый файл. Большая часть форматирования будет потеряна, но книга откроется любой программой;', 'download/formats/375258589247.png', 1, 14),
(6, 2, '.rtf', 'текст с форматированием, удобен для чтения на компьютере и печати;', 'download/formats/112945185492.png', 1, 13),
(7, 3, '.pdf', 'документ АдоЬе Acrobat. Вариант для листа A4 прекрасно подходит для распечатки, версия Аб годится для чтения на многих e-ink читалках, таких как Sony PRS;', 'download/formats/286772381131.png', 1, 8),
(8, 2, '.htm', 'гипертекст. Может быть открыт веб-браузером, множеством читалок и редакторов;', 'download/formats/538445192486.png', 1, 7),
(9, 3, '.pdf', 'документ АдоЬе Acrobat. Вариант для листа A4 прекрасно подходит для распечатки, версия Аб годится для чтения на многих e-ink читалках, таких как Sony PRS;', 'download/formats/357766862395.png', 0, 9),
(10, 3, '.mobi', 'документы mobi, поддерживаются устройством Amazon Kindle, так же имеется кpoccппaтформeнный ридер;', 'download/formats/936553118647.png', 1, 6),
(11, 4, '.txt', 'стандартный текстовый файл. Большая часть форматирования будет потеряна, но книга откроется любой программой;', 'download/formats/386143227325.png', 0, 15),
(12, 4, '.java', 'java-книги для чтения на мобильном телефоне. Поддерживаются все модели телефонов, работающие c Java;', 'download/formats/787919339525.png', 1, 12),
(13, 5, '.isilo3', 'специализированный формат для продвинyтой программы-читалки i5iIo, доступной для многих платформ (Windows mobile, Рант);', 'download/formats/343676511899.png', 1, 10),
(14, 5, '.rb', 'книги для специализированных устройств Rockete-book/REB11o0;', 'download/formats/549197571426.png', 1, 11),
(15, 5, '.lrf', 'формат, используемый в семействе устройств Sony Reader;', 'download/formats/437312596794.png', 1, 4),
(16, 5, '.lit', 'формат для программы-читалки Microsoft Аеадег Программа существует для всей линейки Windows, в числе прочего умеет «читать текст книги вслух»;', 'download/formats/747861244747.png', 1, 2),
(17, 5, '.doc', 'документы для чтения на Palm (Mobi Pocket и т.п.);', 'download/formats/237915399565.png', 1, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `formats_categories`
--

DROP TABLE IF EXISTS `formats_categories`;
CREATE TABLE IF NOT EXISTS `formats_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `formats_categories`
--

INSERT INTO `formats_categories` (`id`, `ru_title`, `en_title`, `visible`, `sort`) VALUES
(1, 'Удобные', 'Comfortable', 1, 3),
(2, 'Для компьютера', 'For PC', 1, 2),
(3, 'Для ридеров', 'For readers', 1, 1),
(4, 'Для телефона', 'For phones', 1, 4),
(5, 'Другие', 'Other', 1, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `genres`
--

DROP TABLE IF EXISTS `genres`;
CREATE TABLE IF NOT EXISTS `genres` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `genres`
--

INSERT INTO `genres` (`id`, `ru_title`, `en_title`, `sort`) VALUES
(1, 'Драма', 'Drama', 1),
(2, 'Боевик', 'Action', 2),
(3, 'Фантастика', 'Fantastic', 3),
(5, 'Учебное пособие', 'Schoolbook', 4),
(6, 'Фантастика', 'Fantastic', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `word_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `keywords`
--

INSERT INTO `keywords` (`id`, `word`, `word_hash`) VALUES
(1, 'Learn', '2f1a3e62508d88ddc31f1aa72a8334d4'),
(2, 'Laravel', 'a5c95b86291ea299fcbe64458ed12702'),
(3, 'MVC', '0b9221b0599697618c27449e89d9b07a'),
(4, 'Проза', '73ad20df7e49f8cd29e068a0a22a11e3'),
(5, 'История жизни', 'e7a0753688880bdb80829b5c4851b9fa'),
(6, 'fan', '50bd8c21bfafa6e4e962f6a948b1ef92'),
(7, 'girl', '28ca53d2b7bb4aa13549b4022c79dca1'),
(8, 'island', '3dbacfd76b0a040ccad1eacb20def4c8');

-- --------------------------------------------------------

--
-- Структура таблицы `matching`
--

DROP TABLE IF EXISTS `matching`;
CREATE TABLE IF NOT EXISTS `matching` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` int(10) unsigned NOT NULL,
  `book` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Дамп данных таблицы `matching`
--

INSERT INTO `matching` (`id`, `word`, `book`) VALUES
(38, 8, 10),
(37, 4, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `meta_titles`
--

DROP TABLE IF EXISTS `meta_titles`;
CREATE TABLE IF NOT EXISTS `meta_titles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(10) NOT NULL,
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `page_address` varchar(200) NOT NULL,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` text NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Дамп данных таблицы `meta_titles`
--

INSERT INTO `meta_titles` (`id`, `group`, `item_id`, `page_address`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`) VALUES
(28, 'news', 5, '73-pokupateleiy-e-knig-60-pechatnyh-zayavili-chto-schitayut-chtenie-vajnoiy-chastyu-svoeiy-jizni', '', '', '', '', '', ''),
(3, 'news', 1, 'novaya-kniga', '', '', '', '', '', ''),
(4, 'news', 2, 'otkrytie-magazina', '', '', '', '', '', ''),
(5, 'books', 3, 'fanatka-chast-2', '', '', '', '', '', ''),
(6, 'books', 4, 'fanatka-chast-3', '', '', '', '', '', ''),
(7, 'books', 5, 'fanatka-chat-4', '', '', '', '', '', ''),
(8, 'interface', 1, 'home', 'Главная страница', 'Главная страница', 'Главная страница', 'Главная страница', 'Главная страница', 'Главная страница'),
(9, 'interface', 2, 'editing', 'Редактирование', 'Редактирование', 'Редактирование', 'Редактирование', 'Редактирование', 'Редактирование'),
(10, 'interface', 3, 'typography', 'Оформление', 'Оформление', 'Оформление', 'Оформление', 'Оформление', 'Оформление'),
(11, 'interface', 4, 'translation', 'Перевод', 'Перевод', 'Перевод', 'Перевод', 'Перевод', 'Перевод'),
(12, 'interface', 5, 'distribution', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция'),
(13, 'interface', 6, 'undefined', 'Каталог', 'Каталог', 'Каталог', 'Каталог', 'Каталог', 'Каталог'),
(14, 'interface', 7, 'about', 'О проекте', 'О проекте', 'О проекте', 'О проекте', 'О проекте', 'О проекте'),
(15, 'interface', 8, 'basket', 'Корзина', 'Корзина', 'Корзина', 'Корзина', 'Корзина', 'Корзина'),
(16, 'interface', 9, 'cabinet', 'Мои купленные книги', 'Мои книги', 'Мои книги', 'My books purchased', 'Мои книги', 'Мои книги'),
(17, 'interface', 10, 'formats', 'Форматы', 'Форматы', 'Форматы', 'Форматы', 'Форматы', 'Форматы'),
(18, 'interface', 11, 'search', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска'),
(19, 'interface', 12, 'catalog', 'Каталог книг', 'Каталог', 'Каталог', 'Books catalog', 'Каталог', 'Каталог'),
(20, 'interface', 13, 'trailers', 'Трейлеры', 'Трейлеры', 'Трейлеры', 'Трейлеры', 'Трейлеры', 'Трейлеры'),
(21, 'books', 6, 'thefanatka', '', '', '', '', '', ''),
(22, 'books', 7, 'softmen', '', '', '', '', '', ''),
(23, 'books', 8, 'slepoe-znamya-durakov', '', '', '', '', '', ''),
(24, 'books', 9, 'the-blind-banner-of-the-fools', '', '', '', '', '', ''),
(25, 'books', 10, 'temptation-island', '', '', '', '', '', ''),
(26, 'news', 3, 'kulturnaya-jizn-evropeiycev', '', '', '', '', '', ''),
(27, 'news', 4, 'otchet-o-mirovom-rynke-lektronnyh-knig', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(200) NOT NULL,
  `en_title` varchar(200) NOT NULL,
  `ru_small_anonce` varchar(100) NOT NULL,
  `en_small_anonce` varchar(100) NOT NULL,
  `ru_anonce` text NOT NULL,
  `en_anonce` text NOT NULL,
  `ru_text` text NOT NULL,
  `en_text` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `ru_title`, `en_title`, `ru_small_anonce`, `en_small_anonce`, `ru_anonce`, `en_anonce`, `ru_text`, `en_text`, `image`, `thumbnail`, `date`, `sort`) VALUES
(5, 'Портрет потребителя цифрового контента', 'Portrait of the consumer digital content', '73% покупателей е-книг (60% — печатных) заявили, что считают чтение важной частью своей жизни.', 'Random House suggested another portrait of the consumer digital content', '73% покупателей е-книг (60% – печатных) заявили, что считают чтение важной частью своей жизни. Один из лидеров мирового рынка книгоиздания Random House объединил данные нескольких исследований и предложил еще один портрет потребителя цифрового контента. Данные опросов покупателей книг в США, которые регулярно мониторит исследовательское подразделение издательского гиганта Random House, позволяют получить представление, в частности, о читательских привычках пользователей цифрового контента. Учитывая актуальность темы, специалисты издательства собрали воедино результаты нескольких исследований и предложили свой портрет читателя электронных книг.', 'One of the world''s leading publishing Random House has combined data from several studies and suggested another portrait of the consumer digital content.\nSurvey data book buyers in the U.S., which regularly monitors the research division of publishing giant Random House, give an idea, in particular, about the reading habits users of digital content. Given the relevance of the topic, publishing professionals gathered together the results of several studies and offered his portrait readers of electronic books.', '<p>\n	    Итак, к чтению книг в цифровом формате приобщился каждый пятый взрослый американец, причем зачастую это активные читатели, которые не отказываются и от традиционной книжной продукции. В цифрах картина такова: 63% покупателей е-книг — женщины, в то время как среди тех, кто предпочитает «бумагу», представительниц прекрасного пола 59%; 60% читателей е-книг моложе 45 лет (против 53%); 66% окончили высшие учебные заведения или имеют степень; 40% имеют доход на семью более 75 тысяч долларов (среди читателей печатных книг таковых 34%). Что касается жанров, которые выбирают любители е-книг, предпочтения распределились следующим образом: 44% — мистика и детективы, 40% — популярная художественная литература, 24% — любовные романы, 23% — юмористическая литература, 20% — историческая.\n</p>\n<p>\n	    38% покупателей цифровых книг признались в том, что последняя приобретенная книга обошлась им меньше чем в 5 долларов (среди любителей печатных книг, которым сложнее быть экономными — 18%). Наконец, 73% покупателей е-книг (60% — печатных) заявили, что считают чтение важной частью своей жизни, 51% (37%) любят обсуждать книги со своей семьей и друзьями, 34% (23%) следят за новинками. Не вполне понятно, насколько репрезентативным можно считать соотношение цифр по группам любителей цифровых и печатных книг, однако портрет читателя е-книг аналитикам набросать удалось.\n</p>\n<p>\n	    Источник: <a href="http://www.randomhouse.com/" target="_blank">Random House</a>.\n</p>', '<p>\n	   So, to read books in digital format joined every five American adults, often are active readers who do not give up the traditional book production. In numbers, the picture is as follows: 63% of buyers of e-books — women, while among those who prefer the «paper», the fair sex is 59%, 60% of e-book readers under the age of 45 years (vs. 53%), 66% graduated from higher education institutions or have a degree and 40% have a household income of more than $75 thousand (among readers of printed books such 34%). As for genres, fans who choose e-books, the preferences were as follows: 44% — Mysticism and detectives, 40% — popular fiction, 24% — romance, 23% — a humorous literature, 20% — historical.\n</p>\n<p>\n	   38% of buyers of digital books have admitted that the latter acquired the book cost them less than $5 (amateur printed books that are difficult to be economical — 18%). Finally, 73% of buyers of e-books (60% — printed) said they consider reading an important part of their lives, 51% (37%) like to discuss the book with your family and friends, 34% (23%) watch novelties. It is not clear how much can be considered representative of the ratio of numbers in groups amateur digital and print books, but the portrait of the reader e-books analysts to outline possible.\n</p>\n<p>\n	 <a href="http://www.randomhouse.com/">Random House</a>.\n</p>', '', '', '2013-10-31 00:00:00', 0),
(3, 'Культурная жизнь европейцев', 'Cultural life of Europeans', 'Еврокомиссия опубликовала результаты соцопроса об участии европейцев в культурной жизни.', 'The European Commission published the results of the poll to participate in the cultural life of Eur', 'По данным социологического сервиса Еврокомиссии — Евробарометра — 68% граждан ЕС за последние 12 месяцев прочитали хотя бы одну книгу. Это лишь немногим менее, чем количество людей, просмотревших за последний год хотя бы одну культурную телепередачу или прослушавших радиопрограмму о культуре (72%). Больше всего читают в Швеции (90%), Нидерландах (86%) и Дании (82%). Меньше всего — в Румынии (51%) и Греции (50%).', 'According to the sociological service of the European Commission — Eurobarometer — 68% of EU citizens over the past 12 months, read at least one book. This is only slightly less than the number of people who have viewed over the last year at least one cultural TV program or listen to a radio program about culture (72%). Most read in Sweden (90%), the Netherlands (86%) and Denmark (82%). Less — in Romania (51%) and Greece (50%).', '<p>\n	   Точных данных о том, сколько из читателей в Европе пользуются электронными версиями книг, нет, однако известно, что книги, компакт-диски либо билеты на культурные меропрития в Интернете покупают 27% опрошенных. Меньше всего — лишь 5% опрошенных — покупали подобные культурные продукты в Болгарии, а больше всего — 53% и 52% соответственно — в Швеции и Дании. В Германии книги, диски или билеты покупают в Интернете 44% опрошенных, а в Великобритании и Франции — 30% и 31% соответственно.\n</p>\n<p>\n	   Относительно немного европейцев ходят в библиотеку: 31%. Главной причиной для этого называют слабый интерес (43% тех, кто не ходит), в то время как главной причиной для непрочтения книг дома является отсутствие времени (44%). Читающие европейцы далеко не всегда интересуются творчеством своих соседей по Евросоюзу. Так, лишь 27% за последний год прочитали книгу какого-либо европейского автора не из их собственной страны.\n</p>\n<p>\n	  Источник: <a href="http://pro-books.ru/" target="_blank">pro-books.ru</a>\n</p>', '<p>\n	 Accurate data on how many of the readers in Europe are electronic versions of books, no, but we know that books, CDs or tickets to cultural events online buy 27% of the respondents. Less — only 5% of respondents — such cultural products bought in Bulgaria, and most of all — 53% and 52%, respectively — in Sweden and Denmark. In Germany, books, CDs or tickets purchased on the Internet 44% of respondents, while in the UK and France — 30% and 31%, respectively.\n</p>\n<p>\n	 Relatively few Europeans go to the library: 31%. The main reason for this is called weak interest (43% of those who do not go), while the main reason for the unread books at home is the lack of time (44%). Readers Europeans are not always interested in the work of its neighbors in the European Union. Thus, only 27% over the last year have read the book of a European author is not from their own country.\n</p>\n<p>\n	 <a href="http://pro-books.ru/" target="_blank">pro-books.ru</a>\n</p>', '', '', '2013-11-06 00:00:00', 0),
(4, 'Мировой рынок электронных книг', 'Global market for e-books', 'Новый отчет о мировом рынке электронных книг, подготовлен экспертом Рудигером Вишенбартом.', 'A new report on the global e-book market, prepared by an expert Rudiger Vishenbartom.', 'Целью исследования Global eBook, подготовленного известным консультантом и аналитиком рынка Рудигером Вишенбартом (Ruediger Wischenbart), является попытка изучить тенденции на рынке электронных книг в США и Великобритании, а также в ряде стран, где е-книги для многих вcе еще в новинку. Среди последних — страны континентальной Европы, Бразилия и Россия.', 'The aim of the study Global eBook, prepared by well-known consultant and market analyst Ruediger Wischenbart, is an attempt to examine the trends in the market of electronic books in the U.S. and the UK, as well as in a number of countries where e-books for all thumbnails many still new. Among the latter — the countries of continental Europe, Brazil, and Russia.', '<p>\n	   Отчет не претендует на полную картину состояния данного сектора книжного рынка и не сравнивает страны по всем показателям. Скорее, он отображает наиболее интересные для авторов тенденции на основе анализа доступных данных из третьих источников. Вот только некоторые из приведенных в отчете фактов и тенденций:\n</p>\n<p>\n	 <strong>Великобритания и США</strong>\n</p>\n<ul>\n	<li>В США и Великобритании электронные книги составляют 20% и 12,9% от общего книжного оборота.</li>\n	<li>У крупнейших американских издателей доходы с продаж электронных книг составляют от 30% до 40%. Однако в 2013 году продажи электронных книг в стране упали. Доля американцев в возрасте от 16 лет, читающих электронные книги, выросла с 16% до 23%.</li>\n	<li>Планшеты продолжают наступать на е-ридеры. В 2012 году наиболее предпочтительной платформой для чтения электронных книг в США был Kindle Fire от Amazon, на втором месте был iPad от фирмы Apple.</li>\n	<li>Наибольшей популярностью пользовались трилогия Э. Л. Джеймс «Пятьдесят оттенков серого» и «Голодные игры» Сьюзен Коллинз. 43 из топ-50 скачиваемых книг были изданы «традиционными» издателями.</li>\n</ul>\n<p>\n	 <strong>Континентальная Европа</strong>\n</p>\n<ul>\n	<li>В Германии электронные книги составляют около 5% от книжного оборота. 84% немецких издателей либо предлагают электронные книги, либо в ближайшее время собираются их предлагать. При этом половину всего немецкого рынка электронных книг занимает Amazon.</li>\n	<li>Чтобы бороться с доминированием Amazon на рынке электронных ридеров, крупнейшие книготорговые сети, Thalia и Weltbild-Hugendubel выпустили в продажу собственный, более дешевый, чем Kindle, ридер Tolino, стоящий €99.</li>\n	<li>Во Франции книги остаются наиболее популярным среди покупателей форматом массовой культуры.</li>\n	<li>Продажи электронных книг во Франции составили 2–3% от общих продаж. В электронном формате доступно около 126 тысяч наименований.</li>\n	<li>В Испании электронные книги составляют 3% от общего объема рынка. При этом в 2012 году этот показатель составлял лишь 1%</li>\n	<li>В Италии электронные книги составляют лишь 0,9% от общего объема, но их распространение также быстро растет. Средняя цена электронной книги в 2012 году там составляла €11,07 — на 11 центов меньше, чем в 2011 году. На е-книги сохраняется высокий НДС: в 2012 году он вырос до 21% с 20%. В то же время НДС на бумажные книги составляет всего 4%.</li>\n</ul>\n<p>\n	 <strong>Скандинавия</strong>\n</p>\n<ul>\n	<li>В Швеции и Норвегии рынок электронных книг все еще на стадии зарождения, поэтому о доле е-книг в объемах продаж и выручки сказать сложно.</li>\n	<li>В то же время, правительство поощряет написание и издание книг. В Норвегии существует специальная программа государственных грантов для поощрения писателей.</li>\n</ul>\n<p>\n	 <strong>Бразилия</strong>\n</p>\n<ul>\n	<li>В декабре 2012 года с разрывом в несколько часов свои адаптированные под Бразилию версии сайтов с электронными книгами запустили Amazon, Google и Kobo. Однако на середину 2013 года лидером продаж е-книг в стране являлся Apple.</li>\n	<li>По состоянию на май 2013 года в Бразилии доступно 25 000 наименований электронных книг на португальском языке. Это серьезный рост в сравнении с февралем 2011 года, когда их насчитывалось 11 000.</li>\n</ul>\n<p>\n	 <strong>Россия</strong>\n</p>\n<ul>\n	<li>70% россиян когда-либо читали электронные книги.</li>\n	<li>При этом 92% «бесплатно» скачивают книги из Интернета. Это включает в себя и пиратское скачивание файлов.</li>\n	<li>Книжный рынок в России в целом развивался в последние годы «сложно и нестабильно», в первую очередь, из-за кризиса 2008 года.</li>\n	<li>Легальный рынок е-книг в России в 2012 году оценивается в 260 млн руб. (вырос почти вдвое по сравнению с оценкой 135 млн руб. в 2011 году), составляя менее 1% в общем объеме рынка.</li>\n	<li>В 2012 году «структура рынка значительно изменилась под влиянием внутренних и международных сил». Одним из главных внутренних факторов стало объединение АСТ с «Эксмо».</li>\n	<li>«Из-за огромной территории — которая покрывает девять временных зон — распространение бумажных книг в России является чрезвычайно сложным и дорогим занятием. А учитывая, что лишь немногие покупатели имеют кредитные карточки, а пиратство широко распространено, Россия является особенно сложным рынком для издателей и книготорговцев. В то же время в России существует традиционная культура чтения».</li>\n	<li>Проникновение на рынок е-ридеров и планшетов «кажется, значительно ускорилось и достигло 200% в 2012 году».</li>\n</ul>\n<p>\n	   Полный вариант исследования Global eBook вы можете найти на сайте <a href="http://www.global-ebook.com/" target="_blank">Global-ebook</a>.\n</p>', '<p>\n	   The report does not claim to be a complete picture of the state of the sector of the book market and compares countries on all counts. Rather, it displays the most interesting trends the authors on the basis of the analysis of data available from third party sources. Here are just some of the topics in the statement of facts and trends:\n</p>\n<p>\n	 <strong>Britain and the U.S.</strong>\n</p>\n<ul>\n	<li>In the U.S. and UK e-books account for 20% and 12.9% of total book sales.</li>\n	<li>In the largest U.S. publishers revenue from sales of electronic books range from 30% to 40%. However, in 2013, e-book sales in the country fell. The proportion of Americans aged 16 years, reading e-books, rose from 16% to 23%.</li>\n	<li>Tablets continue to advance on e-readers. In 2012, the most preferred platform for reading e-books in the U.S. was the Kindle Fire from Amazon, in second place was the iPad from the company Apple.</li>\n	<li>The most popular trilogy E. L. Dzheyms «Fifty shades of gray» and «The Hunger Games» Suzanne Collins. 43 of the top 50 downloaded books have been published in the «traditional» publishers.</li>\n</ul>\n<p>\n	 <strong>Continental Europe</strong>\n</p>\n<ul>\n	<li>In Germany, e-books account for about 5% of book sales. 84% of German publishers or offer e-books, or in the near future are going to their offering. In this case, half of the German e-book market is Amazon.</li>\n	<li>To combat the dominance of Amazon e-readers on the market, the largest bookselling network, Thalia and Weltbild-Hugendubel released for sale own, cheaper than the Kindle, reader Tolino, worth €99.</li>\n	<li>In France, the books are still the most popular format among consumers of popular culture.</li>\n	<li>E-book sales in France amounted to 3.2% of total sales. The electronic format is available about 126 thousand items.</li>\n	<li>In Spain, e-books account for 3% of the total market. Thus in 2012 the figure was only 1%.</li>\n	<li>In Italy, e-books accounted for only 0.9% of the total, but their distribution is also growing rapidly. The average price of e-books in 2012, there was €11,07 — 11 cents less than in 2011. To e-books is still a high VAT: in 2012 it rose to 21% from 20%. At the same time, the VAT on paper books is only 4%.</li>\n</ul>\n<p>\n	 <strong>Scandinavia</strong>\n</p>\n<ul>\n	<li>In Sweden and Norway, e-book market is still in its infancy, so the percentage of e-books in sales and earnings is difficult to say.</li>\n	<li>At the same time, the government is encouraging the writing and publishing books. In Norway, there is a special program of state grants to encourage writers.</li>\n</ul>\n<p>\n	 <strong>Brazil</strong>\n</p>\n<ul>\n	<li>In December 2012, at intervals of a few hours of their adapted to Brazil versions of sites with e-books launched Amazon, Google and Kobo. However, in mid-2013 best-selling e-books in the country was Apple.</li>\n	<li>As of May 2013 in Brazil available 25,000 titles of e-books in Portuguese. This is a significant increase compared to February 2011, when there were 11,000.</li>\n</ul>\n<p>\n	 <strong>Russia</strong>\n</p>\n<ul>\n	<li>70% of Russians have ever read e-books.</li>\n	<li>Moreover, 92% «free» download books from the Internet. This includes piracy and downloading files.</li>\n	<li>The Book Market in Russia as a whole has developed in the last years of the «complex and unstable», in the first place, because of the crisis in 2008.</li>\n	<li>Legal market e-books in Russia in 2012 is estimated at 260 million rubles. (almost doubled compared with the assessment of 135 million rubles. in 2011), accounting for less than 1% of the total market.</li>\n	<li>In 2012, «the structure of the market has changed significantly under the influence of domestic and international forces». One of the major internal factors was the merger with AST «Eksmo».</li>\n	<li>«Because of the vast area — which covers nine time zones — distributing paper books in Russia is extremely difficult and costly exercise. And given that only a few customers have credit cards, and piracy is widespread, Russia is a particularly difficult market for publishers and booksellers. At the same time, Russia has a traditional culture of reading».</li>\n	<li>The market penetration of e-readers and tablets, «it seems, was greatly accelerated and reached 200% in 2012».</li>\n</ul>\n<p>\n	   A full version of the study Global eBook you can find at <a href="http://www.global-ebook.com/">Global-ebook</a>.\n</p>', '', '', '2013-11-01 00:00:00', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('6d4c88801185c8708747995e944f5500', '77.66.229.51', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0', 1384638610, ''),
('bb306a293df0677f6c25e038261e5c64', '77.66.229.51', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36', 1384590358, 'a:4:{s:9:"user_data";s:0:"";s:5:"logon";s:32:"c743bcded72319c6f8e878b3edf094bd";s:7:"account";s:22:"{"id":"1","group":"1"}";s:7:"profile";s:267:"{"id":"1","vkid":null,"vk_access_token":"","facebook_access_token":"","facebookid":null,"group":"1","login":"admin","email":"admin@distribbooks.ru","password":"e10adc3949ba59abbe56e057f20f883e","signdate":"2013-07-30 11:54:52","active":"1","language":"1","basket":""}";}'),
('62f3ca0096e7174f2bf3c08f8b63e396', '178.76.234.1', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0', 1384754223, ''),
('116034814b5765bb0f29d20535853f0c', '46.138.82.76', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0', 1384721517, 'a:1:{s:9:"user_data";s:0:"";}'),
('575501d1c207acb7de4d35c2e46ba13e', '178.76.234.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', 1384761116, 'a:1:{s:9:"user_data";s:0:"";}'),
('9a617dd7ee5cd79bb1aaa5686d810c0d', '83.102.160.18', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0', 1384760651, 'a:1:{s:9:"user_data";s:0:"";}'),
('672f4ba46711133d96a064ebdeb48c8e', '66.77.136.153', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 7.1; Trident/5.0)', 1384758679, ''),
('8eb5552ab7f4421ee06d99bbf1f89a26', '109.233.204.159', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', 1384760283, '');

-- --------------------------------------------------------

--
-- Структура таблицы `signed_books`
--

DROP TABLE IF EXISTS `signed_books`;
CREATE TABLE IF NOT EXISTS `signed_books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `book` int(10) unsigned NOT NULL,
  `account` int(10) unsigned NOT NULL,
  `date_signed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `signed_books`
--

INSERT INTO `signed_books` (`id`, `book`, `account`, `date_signed`) VALUES
(1, 2, 2, '2013-11-08 12:52:25'),
(2, 1, 2, '2013-11-08 12:52:25'),
(3, 3, 2, '2013-11-08 13:35:19'),
(4, 2, 3, '2013-11-12 08:42:59');

-- --------------------------------------------------------

--
-- Структура таблицы `users_accounts`
--

DROP TABLE IF EXISTS `users_accounts`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `distribbooks`.`users_accounts` AS select `distribbooks`.`accounts`.`id` AS `id`,`distribbooks`.`accounts`.`group` AS `group`,`distribbooks`.`accounts`.`email` AS `email`,`distribbooks`.`accounts`.`signdate` AS `signdate`,`distribbooks`.`accounts`.`active` AS `active`,`distribbooks`.`accounts`.`language` AS `language`,`distribbooks`.`users`.`id` AS `account`,`distribbooks`.`users`.`balance` AS `balance`,`distribbooks`.`users`.`name` AS `name`,`distribbooks`.`users`.`surname` AS `surname`,`distribbooks`.`users`.`gender` AS `gender`,`distribbooks`.`users`.`age` AS `age`,`distribbooks`.`users`.`country` AS `country`,`distribbooks`.`users`.`city` AS `city` from (`distribbooks`.`accounts` join `distribbooks`.`users` on((`distribbooks`.`accounts`.`account` = `distribbooks`.`users`.`id`))) where (`distribbooks`.`accounts`.`group` = 2);
-- используется (#1356 - View 'distribbooks.users_accounts' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Структура для представления `books_card`
--
DROP TABLE IF EXISTS `books_card`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `books_card` AS select `meta_titles`.`id` AS `meta_id`,`meta_titles`.`page_address` AS `page_address`,`meta_titles`.`ru_page_title` AS `ru_page_title`,`meta_titles`.`ru_page_description` AS `ru_page_description`,`meta_titles`.`ru_page_h1` AS `ru_page_h1`,`meta_titles`.`en_page_title` AS `en_page_title`,`meta_titles`.`en_page_description` AS `en_page_description`,`meta_titles`.`en_page_h1` AS `en_page_h1`,`books`.`id` AS `id`,`books`.`ru_title` AS `ru_title`,`books`.`en_title` AS `en_title`,`books`.`ru_anonce` AS `ru_anonce`,`books`.`en_anonce` AS `en_anonce`,`books`.`ru_text` AS `ru_text`,`books`.`en_text` AS `en_text`,`books`.`image` AS `image`,`books`.`thumbnail` AS `thumbnail`,`books`.`date_released` AS `date_released`,`books`.`ru_size` AS `ru_size`,`books`.`en_size` AS `en_size`,`books`.`isbn` AS `isbn`,`books`.`ru_sort` AS `ru_sort`,`books`.`en_sort` AS `en_sort`,`books`.`age_limit` AS `age_limit`,`books`.`authors` AS `authors`,`books`.`files` AS `files`,`books`.`genre` AS `genre`,`books`.`rating` AS `rating`,`books`.`currency` AS `currency`,`books`.`price` AS `price`,`books`.`price_action` AS `price_action`,`books`.`trailers` AS `trailers`,`books`.`audio_recording` AS `audio_recording`,`books`.`ru_copyright` AS `ru_copyright`,`books`.`en_copyright` AS `en_copyright` from (`books` left join `meta_titles` on((`books`.`id` = `meta_titles`.`item_id`))) where (`meta_titles`.`group` = 'books');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
