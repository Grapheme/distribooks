-- phpMyAdmin SQL Dump
-- version 3.4.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 12 2013 г., 16:09
-- Версия сервера: 5.1.71
-- Версия PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `distribbooks`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vkid` int(10) unsigned DEFAULT NULL,
  `vk_access_token` text NOT NULL,
  `facebook_access_token` text NOT NULL,
  `facebookid` bigint(20) unsigned DEFAULT NULL,
  `group` tinyint(1) NOT NULL DEFAULT '1',
  `login` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `signdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `language` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `basket` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `group` (`group`),
  KEY `language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `vkid`, `vk_access_token`, `facebook_access_token`, `facebookid`, `group`, `login`, `email`, `password`, `signdate`, `active`, `language`, `basket`) VALUES
(1, NULL, '', '', NULL, 1, 'admin', 'admin@distribbooks.ru', 'e10adc3949ba59abbe56e057f20f883e', '2013-07-30 07:54:52', 1, 1, ''),
(2, NULL, '', '', NULL, 2, 'id2', 'sm@grapheme.ru', '96be28150d49ce2bf16007eb3538c2da', '2013-11-08 12:43:07', 1, 1, ''),
(3, NULL, '', '', NULL, 2, 'id3', 'ks-t77@yandex.ru', '96a3a46d4af58c9104008ee199e788cd', '2013-11-12 08:36:01', 1, 1, '');

-- --------------------------------------------------------

--
-- Структура таблицы `age_limit`
--

DROP TABLE IF EXISTS `age_limit`;
CREATE TABLE IF NOT EXISTS `age_limit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `age_limit`
--

INSERT INTO `age_limit` (`id`, `title`, `image`) VALUES
(1, '0+', 'download/age_limits/0.png'),
(2, '6+', 'download/age_limits/6.png'),
(3, '12+', 'download/age_limits/12.png'),
(4, '16+', 'download/age_limits/16.png'),
(5, '18+', 'download/age_limits/18.png');

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ru_name` varchar(100) NOT NULL,
  `en_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`id`, `ru_name`, `en_name`) VALUES
(1, 'Chris Fidao', 'Chris Fidao'),
(2, 'Марина Пивоварова', 'Marina Pivovarova');

-- --------------------------------------------------------

--
-- Структура таблицы `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(200) NOT NULL,
  `en_title` varchar(200) NOT NULL,
  `ru_anonce` text NOT NULL,
  `en_anonce` text NOT NULL,
  `ru_text` text NOT NULL,
  `en_text` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  `date_released` varchar(50) NOT NULL,
  `ru_size` varchar(50) NOT NULL,
  `en_size` varchar(50) NOT NULL,
  `isbn` varchar(50) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `age_limit` int(10) unsigned NOT NULL,
  `authors` text NOT NULL,
  `files` text NOT NULL,
  `genre` int(10) unsigned NOT NULL,
  `rating` tinyint(2) unsigned NOT NULL,
  `currency` int(10) unsigned NOT NULL DEFAULT '1',
  `price` float unsigned NOT NULL,
  `price_action` float unsigned NOT NULL,
  `trailers` text NOT NULL,
  `audio_recording` text NOT NULL,
  `ru_copyright` text NOT NULL,
  `en_copyright` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `books`
--

INSERT INTO `books` (`id`, `ru_title`, `en_title`, `ru_anonce`, `en_anonce`, `ru_text`, `en_text`, `image`, `thumbnail`, `date_released`, `ru_size`, `en_size`, `isbn`, `sort`, `age_limit`, `authors`, `files`, `genre`, `rating`, `currency`, `price`, `price_action`, `trailers`, `audio_recording`, `ru_copyright`, `en_copyright`) VALUES
(5, 'Фанатка (4)', 'Fanatka', 'Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.', '', '<p>\n	     Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.\n</p>\n<p>\n	     Элис случайно узнаёт, что одна из её подруг обладает способностью читать мысли и заглядывать в будущее. Всё осложняется, когда однажды, используя свои способности, девушка оказалась неразрывно связанной на астральном уровне с одним из солистов группы, который теперь живёт сразу в двух мирах: в одном — он рок-звезда, страдающая от алкоголизма, в другом — обычный парень, влюблённый в прекрасную девушку Анжелу, подругу Элис.  К чему приведут игры с чужим подсознанием, вы узнаете, прочитав книгу издательства DistribBooks «Фанатка»!\n</p>', '', 'download/books/491396537191.jpg', 'download/books/862689239475.jpg', '2013-10-13', '250 стр.', '', '-', 5, 5, '2', '', 6, 0, 1, 650, 600, '["<iframe width=\\"560\\" height=\\"315\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '["<iframe width=\\"100%\\" height=\\"166\\" scrolling=\\"no\\" frameborder=\\"no\\" src=\\"https:\\/\\/w.soundcloud.com\\/player\\/?url=https%3A\\/\\/api.soundcloud.com\\/tracks\\/117263943&color=ff6600&auto_play=false&show_artwork=true\\"><\\/iframe>"]', 'Distribboks', ''),
(2, 'Фанатка', 'Fanatka', 'Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.', '', '<p>\n	               Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.\n</p>\n<p>\n	               Элис случайно узнаёт, что одна из её подруг обладает способностью читать мысли и заглядывать в будущее. Всё осложняется, когда однажды, используя свои способности, девушка оказалась неразрывно связанной на астральном уровне с одним из солистов группы, который теперь живёт сразу в двух мирах: в одном — он рок-звезда, страдающая от алкоголизма, в другом — обычный парень, влюблённый в прекрасную девушку Анжелу, подругу Элис.  К чему приведут игры с чужим подсознанием, вы узнаете, прочитав книгу издательства DistribBooks «Фанатка»!\n</p>', '', 'download/books/996887857322.jpg', 'download/books/578542259438.jpg', '2013-09-01', '115 стр.', '', '-', 2, 5, '2', '[{"file_name":"588459342635.epub","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/588459342635.epub","raw_name":"588459342635","orig_name":"588459342635.epub","client_name":"Fanatka - Pivovarova Marina.epub","file_ext":".epub","file_size":392.17,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"2","number":1,"sort":1,"caption":""},{"file_name":"711258154738.fb2","file_type":"application\\/xml","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/711258154738.fb2","raw_name":"711258154738","orig_name":"711258154738.fb2","client_name":"Fanatka - Pivovarova Marina.fb2","file_ext":".fb2","file_size":1174.1,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"1","number":2,"sort":2,"caption":""},{"file_name":"955763429587.lit","file_type":"application\\/x-ms-reader","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/955763429587.lit","raw_name":"955763429587","orig_name":"955763429587.lit","client_name":"Fanatka - Pivovarova Marina.lit","file_ext":".lit","file_size":439.23,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"16","number":3,"sort":3,"caption":""},{"file_name":"521913859278.lrf","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/521913859278.lrf","raw_name":"521913859278","orig_name":"521913859278.lrf","client_name":"Fanatka - Pivovarova Marina.lrf","file_ext":".lrf","file_size":476.55,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"15","number":4,"sort":4,"caption":""},{"file_name":"439929365242.rb","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/439929365242.rb","raw_name":"439929365242","orig_name":"439929365242.rb","client_name":"Fanatka - Pivovarova Marina.rb","file_ext":".rb","file_size":751.61,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"14","number":5,"sort":5,"caption":""},{"file_name":"217786773597.mobi","file_type":"application\\/octet-stream","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/217786773597.mobi","raw_name":"217786773597","orig_name":"217786773597.mobi","client_name":"Fanatka2 - Pivovarova Marina.mobi","file_ext":".mobi","file_size":793.07,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"10","number":6,"sort":6,"caption":""},{"file_name":"814357111721.rtf","file_type":"text\\/rtf","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/814357111721.rtf","raw_name":"814357111721","orig_name":"814357111721.rtf","client_name":"Fanatka2 - Pivovarova Marina.rtf","file_ext":".rtf","file_size":3521.39,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"6","number":7,"sort":7,"caption":""},{"file_name":"366294343868.txt","file_type":"text\\/plain","file_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/","full_path":"\\/home\\/rikardo\\/data\\/www\\/dev.grapheme.ru\\/distribbooks\\/catalog\\/366294343868.txt","raw_name":"366294343868","orig_name":"366294343868.txt","client_name":"Fanatka2 - Pivovarova Marina.txt","file_ext":".txt","file_size":1007.53,"is_image":false,"image_width":"","image_height":"","image_type":"","image_size_str":"","format_id":"5","number":8,"sort":8,"caption":""}]', 3, 0, 1, 400, 0, '["<iframe width=\\"560\\" height=\\"315\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '["<iframe width=\\"100%\\" height=\\"166\\" scrolling=\\"no\\" frameborder=\\"no\\" src=\\"https:\\/\\/w.soundcloud.com\\/player\\/?url=https%3A\\/\\/api.soundcloud.com\\/tracks\\/117263943&amp;color=ff6600&amp;auto_play=false&amp;show_artwork=true\\"><\\/iframe>"]', 'Distribbooks', ''),
(3, 'Фанатка (2)', 'Fanatka 2', 'Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.', '', '<p>\n	      Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.\n</p>\n<p>\n	      Элис случайно узнаёт, что одна из её подруг обладает способностью читать мысли и заглядывать в будущее. Всё осложняется, когда однажды, используя свои способности, девушка оказалась неразрывно связанной на астральном уровне с одним из солистов группы, который теперь живёт сразу в двух мирах: в одном — он рок-звезда, страдающая от алкоголизма, в другом — обычный парень, влюблённый в прекрасную девушку Анжелу, подругу Элис.  К чему приведут игры с чужим подсознанием, вы узнаете, прочитав книгу издательства DistribBooks «Фанатка»!\n</p>', '', 'download/books/567188436564.jpg', 'download/books/297654573528.jpg', '2013-09-13', '112 стр.', '', '-', 3, 5, '2', '', 6, 0, 1, 450, 0, '["<iframe width=\\"560\\" height=\\"315\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '["<iframe width=\\"100%\\" height=\\"166\\" scrolling=\\"no\\" frameborder=\\"no\\" src=\\"https:\\/\\/w.soundcloud.com\\/player\\/?url=https%3A\\/\\/api.soundcloud.com\\/tracks\\/117263943&color=ff6600&auto_play=false&show_artwork=true\\"><\\/iframe>"]', 'Distribbooks', ''),
(4, 'Фанатка (3)', 'Fanatka 2', 'Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.', '', '<p>\n	     Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.\n</p>\n<p>\n	     Элис случайно узнаёт, что одна из её подруг обладает способностью читать мысли и заглядывать в будущее. Всё осложняется, когда однажды, используя свои способности, девушка оказалась неразрывно связанной на астральном уровне с одним из солистов группы, который теперь живёт сразу в двух мирах: в одном — он рок-звезда, страдающая от алкоголизма, в другом — обычный парень, влюблённый в прекрасную девушку Анжелу, подругу Элис.  К чему приведут игры с чужим подсознанием, вы узнаете, прочитав книгу издательства DistribBooks «Фанатка»!\n</p>', '', 'download/books/118162582326.jpg', 'download/books/559819419691.jpg', '2013-10-02', '38 стр.', '', '-', 4, 5, '2', '', 6, 0, 1, 600, 250, '["<iframe width=\\"560\\" height=\\"315\\" src=\\"\\/\\/www.youtube.com\\/embed\\/YoaNmkOPICA\\" frameborder=\\"0\\" allowfullscreen><\\/iframe>"]', '["<iframe width=\\"100%\\" height=\\"166\\" scrolling=\\"no\\" frameborder=\\"no\\" src=\\"https:\\/\\/w.soundcloud.com\\/player\\/?url=https%3A\\/\\/api.soundcloud.com\\/tracks\\/117263943&color=ff6600&auto_play=false&show_artwork=true\\"><\\/iframe>"]', 'Distribboks', '');

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `books_card`
--
DROP VIEW IF EXISTS `books_card`;
CREATE TABLE IF NOT EXISTS `books_card` (
`meta_id` int(10) unsigned
,`page_address` varchar(200)
,`ru_page_title` text
,`ru_page_description` text
,`ru_page_h1` text
,`en_page_title` text
,`en_page_description` text
,`en_page_h1` text
,`id` int(10) unsigned
,`ru_title` varchar(200)
,`en_title` varchar(200)
,`ru_anonce` text
,`en_anonce` text
,`ru_text` text
,`en_text` text
,`image` varchar(100)
,`thumbnail` varchar(100)
,`date_released` varchar(50)
,`ru_size` varchar(50)
,`en_size` varchar(50)
,`isbn` varchar(50)
,`sort` int(10) unsigned
,`age_limit` int(10) unsigned
,`authors` text
,`files` text
,`genre` int(10) unsigned
,`rating` tinyint(2) unsigned
,`currency` int(10) unsigned
,`price` float unsigned
,`price_action` float unsigned
,`trailers` text
,`audio_recording` text
,`ru_copyright` text
,`en_copyright` text
);
-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dollar_rate` double NOT NULL,
  `free_book` tinyint(1) unsigned NOT NULL,
  `count_free_book` tinyint(1) unsigned NOT NULL,
  `action_price` float unsigned NOT NULL,
  `action_percent` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `config`
--

INSERT INTO `config` (`id`, `dollar_rate`, `free_book`, `count_free_book`, `action_price`, `action_percent`) VALUES
(1, 32.1808, 4, 1, 2000, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `currency`
--

DROP TABLE IF EXISTS `currency`;
CREATE TABLE IF NOT EXISTS `currency` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `currency`
--

INSERT INTO `currency` (`id`, `title`, `image`) VALUES
(1, 'RUR', ''),
(2, 'USD', '');

-- --------------------------------------------------------

--
-- Структура таблицы `formats`
--

DROP TABLE IF EXISTS `formats`;
CREATE TABLE IF NOT EXISTS `formats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sort` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `formats`
--

INSERT INTO `formats` (`id`, `category`, `title`, `description`, `image`, `visible`, `sort`) VALUES
(1, 1, '.fb2', 'открытый формат на основе XML, напрямую читается программой HaaIi Readerи многими другими. Читалки и редакторы существуют для практически любой ОС. Существует так же программа конвертер FB2Any;', 'download/formats/687275461694.png', 1, 1),
(2, 1, '.epub', 'активно продвигаемый фирмой Adobe формат, основанный на HTML. Поддерживается практически во всех современных программах и устройствах;', 'download/formats/586651371165.png', 1, 3),
(5, 2, '.txt', 'стандартный текстовый файл. Большая часть форматирования будет потеряна, но книга откроется любой программой;', 'download/formats/375258589247.png', 1, 14),
(6, 2, '.rtf', 'текст с форматированием, удобен для чтения на компьютере и печати;', 'download/formats/112945185492.png', 1, 13),
(7, 3, '.pdf', 'документ АдоЬе Acrobat. Вариант для листа A4 прекрасно подходит для распечатки, версия Аб годится для чтения на многих e-ink читалках, таких как Sony PRS;', 'download/formats/286772381131.png', 1, 8),
(8, 2, '.htm', 'гипертекст. Может быть открыт веб-браузером, множеством читалок и редакторов;', 'download/formats/538445192486.png', 1, 7),
(9, 3, '.pdf', 'документ АдоЬе Acrobat. Вариант для листа A4 прекрасно подходит для распечатки, версия Аб годится для чтения на многих e-ink читалках, таких как Sony PRS;', 'download/formats/357766862395.png', 0, 9),
(10, 3, '.mobi', 'документы mobi, поддерживаются устройством Amazon Kindle, так же имеется кpoccппaтформeнный ридер;', 'download/formats/936553118647.png', 1, 6),
(11, 4, '.txt', 'стандартный текстовый файл. Большая часть форматирования будет потеряна, но книга откроется любой программой;', 'download/formats/386143227325.png', 0, 15),
(12, 4, '.java', 'java-книги для чтения на мобильном телефоне. Поддерживаются все модели телефонов, работающие c Java;', 'download/formats/787919339525.png', 1, 12),
(13, 5, '.isilo3', 'специализированный формат для продвинyтой программы-читалки i5iIo, доступной для многих платформ (Windows mobile, Рант);', 'download/formats/343676511899.png', 1, 10),
(14, 5, '.rb', 'книги для специализированных устройств Rockete-book/REB11o0;', 'download/formats/549197571426.png', 1, 11),
(15, 5, '.lrf', 'формат, используемый в семействе устройств Sony Reader;', 'download/formats/437312596794.png', 1, 4),
(16, 5, '.lit', 'формат для программы-читалки Microsoft Аеадег Программа существует для всей линейки Windows, в числе прочего умеет «читать текст книги вслух»;', 'download/formats/747861244747.png', 1, 2),
(17, 5, '.doc', 'документы для чтения на Palm (Mobi Pocket и т.п.);', 'download/formats/237915399565.png', 1, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `formats_categories`
--

DROP TABLE IF EXISTS `formats_categories`;
CREATE TABLE IF NOT EXISTS `formats_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `formats_categories`
--

INSERT INTO `formats_categories` (`id`, `ru_title`, `en_title`, `visible`, `sort`) VALUES
(1, 'Удобные', 'Comfortable', 1, 3),
(2, 'Для компьютера', 'For PC', 1, 2),
(3, 'Для ридеров', 'For readers', 1, 1),
(4, 'Для телефона', 'For phones', 1, 4),
(5, 'Другие', 'Other', 1, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `genres`
--

DROP TABLE IF EXISTS `genres`;
CREATE TABLE IF NOT EXISTS `genres` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(100) NOT NULL,
  `en_title` varchar(100) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `genres`
--

INSERT INTO `genres` (`id`, `ru_title`, `en_title`, `sort`) VALUES
(1, 'Драма', 'Drama', 1),
(2, 'Боевик', 'Action', 2),
(3, 'Фантастика', 'Fantastic', 3),
(5, 'Учебное пособие', 'Schoolbook', 4),
(6, 'Фантастика', 'Fantastic', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) NOT NULL,
  `word_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `keywords`
--

INSERT INTO `keywords` (`id`, `word`, `word_hash`) VALUES
(1, 'Learn', '2f1a3e62508d88ddc31f1aa72a8334d4'),
(2, 'Laravel', 'a5c95b86291ea299fcbe64458ed12702'),
(3, 'MVC', '0b9221b0599697618c27449e89d9b07a'),
(4, 'Проза', '73ad20df7e49f8cd29e068a0a22a11e3'),
(5, 'История жизни', 'e7a0753688880bdb80829b5c4851b9fa');

-- --------------------------------------------------------

--
-- Структура таблицы `matching`
--

DROP TABLE IF EXISTS `matching`;
CREATE TABLE IF NOT EXISTS `matching` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` int(10) unsigned NOT NULL,
  `book` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Дамп данных таблицы `matching`
--

INSERT INTO `matching` (`id`, `word`, `book`) VALUES
(17, 4, 2),
(19, 5, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `meta_titles`
--

DROP TABLE IF EXISTS `meta_titles`;
CREATE TABLE IF NOT EXISTS `meta_titles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(10) NOT NULL,
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `page_address` varchar(200) NOT NULL,
  `ru_page_title` text NOT NULL,
  `ru_page_description` text NOT NULL,
  `ru_page_h1` text NOT NULL,
  `en_page_title` text NOT NULL,
  `en_page_description` text NOT NULL,
  `en_page_h1` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Дамп данных таблицы `meta_titles`
--

INSERT INTO `meta_titles` (`id`, `group`, `item_id`, `page_address`, `ru_page_title`, `ru_page_description`, `ru_page_h1`, `en_page_title`, `en_page_description`, `en_page_h1`) VALUES
(1, 'books', 1, 'implementing-laravel', '', '', '', '', '', ''),
(2, 'books', 2, 'fanatka', '', '', '', '', '', ''),
(3, 'news', 1, 'novaya-kniga', '', '', '', '', '', ''),
(4, 'news', 2, 'otkrytie-magazina', '', '', '', '', '', ''),
(5, 'books', 3, 'fanatka-chast-2', '', '', '', '', '', ''),
(6, 'books', 4, 'fanatka-chast-3', '', '', '', '', '', ''),
(7, 'books', 5, 'fanatka-chat-4', '', '', '', '', '', ''),
(8, 'interface', 1, 'home', 'Главная страница', 'Главная страница', 'Главная страница', 'Главная страница', 'Главная страница', 'Главная страница'),
(9, 'interface', 2, 'editing', 'Редактирование', 'Редактирование', 'Редактирование', 'Редактирование', 'Редактирование', 'Редактирование'),
(10, 'interface', 3, 'typography', 'Оформление', 'Оформление', 'Оформление', 'Оформление', 'Оформление', 'Оформление'),
(11, 'interface', 4, 'translation', 'Перевод', 'Перевод', 'Перевод', 'Перевод', 'Перевод', 'Перевод'),
(12, 'interface', 5, 'distribution', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция', 'Дистрибуция'),
(13, 'interface', 6, 'undefined', 'Каталог', 'Каталог', 'Каталог', 'Каталог', 'Каталог', 'Каталог'),
(14, 'interface', 7, 'about', 'О проекте', 'О проекте', 'О проекте', 'О проекте', 'О проекте', 'О проекте'),
(15, 'interface', 8, 'basket', 'Корзина', 'Корзина', 'Корзина', 'Корзина', 'Корзина', 'Корзина'),
(16, 'interface', 9, 'cabinet', 'Мои купленные книги', 'Мои книги', 'Мои книги', 'My books purchased', 'Мои книги', 'Мои книги'),
(17, 'interface', 10, 'formats', 'Форматы', 'Форматы', 'Форматы', 'Форматы', 'Форматы', 'Форматы'),
(18, 'interface', 11, 'search', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска', 'Результаты поиска'),
(19, 'interface', 12, 'catalog', 'Каталог книг', 'Каталог', 'Каталог', 'Books catalog', 'Каталог', 'Каталог');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ru_title` varchar(200) NOT NULL,
  `en_title` varchar(200) NOT NULL,
  `ru_small_anonce` varchar(100) NOT NULL,
  `en_small_anonce` varchar(100) NOT NULL,
  `ru_anonce` text NOT NULL,
  `en_anonce` text NOT NULL,
  `ru_text` text NOT NULL,
  `en_text` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `thumbnail` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `ru_title`, `en_title`, `ru_small_anonce`, `en_small_anonce`, `ru_anonce`, `en_anonce`, `ru_text`, `en_text`, `image`, `thumbnail`, `date`, `sort`) VALUES
(1, 'Новая книга', '', 'В нашем каталоге обновление — опубликована книга Марины Пивоваровой «Фанатка».', '', 'В нашем каталоге обновление — опубликована книга Марины Пивоваровой «Фанатка».', '', '<p>\n	 Это история о жизни девушки Элис, романтичной и верящей во всё сверхъестественное. Она и три её подруги-поклонницы известной рок-группы, солисты которой — секс-символы современной эстрады, братья-близнецы Стюарты.\n</p>', '', '', '', '2013-09-01 00:00:00', 2),
(2, 'Открытие магазина', '', 'Дорогие друзья! Начал работу наш интернет-магазин.', '', 'Дорогие друзья! Начал работу наш интернет-магазин.', '', '<p>\n	 Наши редакторы готовят к публикации новые книги. Пока их не очень много, ведь мы стараемся отобрать только самое лучшее для вас.\n</p>', '', '', '', '2013-11-02 00:00:00', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('47285e3291328d6472c2111be47d7202', '178.76.234.1', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0', 1384257892, 'a:1:{s:9:"user_data";s:0:"";}'),
('a3a6a1f672572d4f919cf6f3c80da29c', '178.76.234.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10B146', 1384248131, ''),
('a67920f14d620bbdbb5e79a51a2fb292', '69.171.237.13', 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)', 1384244214, ''),
('a2de599ccbde2d7350e67a80349190f7', '178.76.218.58', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)', 1384190018, ''),
('a5e546edc666c4359c1edfe3e1e49967', '109.233.204.159', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36', 1384234446, ''),
('0eb1088e391f8a14a3d64bf74ad263f5', '178.76.234.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36', 1384235699, ''),
('bd6ac08d6464010cdd8ed6ebd6583337', '79.98.215.226', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0', 1384245700, 'a:4:{s:9:"user_data";s:0:"";s:5:"logon";s:32:"c18b9fe82f29dd00dca4579b9c295327";s:7:"account";s:22:"{"id":"3","group":"2"}";s:7:"profile";s:283:"{"id":"3","vkid":null,"vk_access_token":"","facebook_access_token":"","facebookid":null,"group":"2","login":"id3","email":"ks-t77@yandex.ru","password":"96a3a46d4af58c9104008ee199e788cd","signdate":"2013-11-12 12:36:01","active":"1","language":"1","basket":"[{{slash}}"2{{slash}}"]"}";}'),
('116034814b5765bb0f29d20535853f0c', '46.138.82.76', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0', 1384253135, 'a:1:{s:9:"user_data";s:0:"";}'),
('a09ba9d39ff15e4c85dd85dc456ea498', '83.102.160.18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36', 1384247697, 'a:1:{s:9:"user_data";s:0:"";}'),
('0181201e8dbed65f251984e4c294618f', '92.124.134.239', 'Mozilla/5.0 (Android; Mobile; rv:25.0) Gecko/25.0 Firefox/25.0', 1384185428, ''),
('19f8c1aeaf4913a312d6a5a4919b89d6', '178.76.234.1', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0', 1384249453, 'a:1:{s:9:"user_data";s:0:"";}'),
('796eafeed0f58b77cd37dd2e7aaf52bf', '178.76.218.58', 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)', 1384189723, 'a:1:{s:9:"user_data";s:0:"";}'),
('4aef1ef72027146adc32aced0bb602f2', '178.76.218.58', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .N', 1384190003, ''),
('b0489caabc1afc66774ffd9d6f29bec2', '188.162.167.49', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36', 1384233473, 'a:1:{s:9:"user_data";s:0:"";}');

-- --------------------------------------------------------

--
-- Структура таблицы `signed_books`
--

DROP TABLE IF EXISTS `signed_books`;
CREATE TABLE IF NOT EXISTS `signed_books` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `book` int(10) unsigned NOT NULL,
  `account` int(10) unsigned NOT NULL,
  `date_signed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `signed_books`
--

INSERT INTO `signed_books` (`id`, `book`, `account`, `date_signed`) VALUES
(1, 2, 2, '2013-11-08 12:52:25'),
(2, 1, 2, '2013-11-08 12:52:25'),
(3, 3, 2, '2013-11-08 13:35:19'),
(4, 2, 3, '2013-11-12 08:42:59');

-- --------------------------------------------------------

--
-- Структура таблицы `users_accounts`
--

DROP TABLE IF EXISTS `users_accounts`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `distribbooks`.`users_accounts` AS select `distribbooks`.`accounts`.`id` AS `id`,`distribbooks`.`accounts`.`group` AS `group`,`distribbooks`.`accounts`.`email` AS `email`,`distribbooks`.`accounts`.`signdate` AS `signdate`,`distribbooks`.`accounts`.`active` AS `active`,`distribbooks`.`accounts`.`language` AS `language`,`distribbooks`.`users`.`id` AS `account`,`distribbooks`.`users`.`balance` AS `balance`,`distribbooks`.`users`.`name` AS `name`,`distribbooks`.`users`.`surname` AS `surname`,`distribbooks`.`users`.`gender` AS `gender`,`distribbooks`.`users`.`age` AS `age`,`distribbooks`.`users`.`country` AS `country`,`distribbooks`.`users`.`city` AS `city` from (`distribbooks`.`accounts` join `distribbooks`.`users` on((`distribbooks`.`accounts`.`account` = `distribbooks`.`users`.`id`))) where (`distribbooks`.`accounts`.`group` = 2);
-- используется (#1356 - View 'distribbooks.users_accounts' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Структура для представления `books_card`
--
DROP TABLE IF EXISTS `books_card`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `books_card` AS select `meta_titles`.`id` AS `meta_id`,`meta_titles`.`page_address` AS `page_address`,`meta_titles`.`ru_page_title` AS `ru_page_title`,`meta_titles`.`ru_page_description` AS `ru_page_description`,`meta_titles`.`ru_page_h1` AS `ru_page_h1`,`meta_titles`.`en_page_title` AS `en_page_title`,`meta_titles`.`en_page_description` AS `en_page_description`,`meta_titles`.`en_page_h1` AS `en_page_h1`,`books`.`id` AS `id`,`books`.`ru_title` AS `ru_title`,`books`.`en_title` AS `en_title`,`books`.`ru_anonce` AS `ru_anonce`,`books`.`en_anonce` AS `en_anonce`,`books`.`ru_text` AS `ru_text`,`books`.`en_text` AS `en_text`,`books`.`image` AS `image`,`books`.`thumbnail` AS `thumbnail`,`books`.`date_released` AS `date_released`,`books`.`ru_size` AS `ru_size`,`books`.`en_size` AS `en_size`,`books`.`isbn` AS `isbn`,`books`.`sort` AS `sort`,`books`.`age_limit` AS `age_limit`,`books`.`authors` AS `authors`,`books`.`files` AS `files`,`books`.`genre` AS `genre`,`books`.`rating` AS `rating`,`books`.`currency` AS `currency`,`books`.`price` AS `price`,`books`.`price_action` AS `price_action`,`books`.`trailers` AS `trailers`,`books`.`audio_recording` AS `audio_recording`,`books`.`ru_copyright` AS `ru_copyright`,`books`.`en_copyright` AS `en_copyright` from (`books` left join `meta_titles` on((`books`.`id` = `meta_titles`.`item_id`))) where (`meta_titles`.`group` = 'books');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
